package com.common;

import java.io.IOException;


public abstract class WeiBo extends basicYuQing{

	public abstract void comment(String userName,String pwd,String url,String mid,String content)throws IOException ;
	
	public abstract void addlike(String userName,String pwd,String mid);
	
	public abstract void forward(String userName,String pwd,String mid,String content);
}
